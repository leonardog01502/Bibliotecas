package View;
import Controller.BdCliente;
import Controller.BdLivro;
import Controller.CriarConexao;
import Model.Livro;
import Controller.BdLivro;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Bilbioteca {
    public static void main(String[] args) throws SQLException {
        /*CriarConexao conexao = new CriarConexao();
        conexao.getConexao();
        BdCliente cliente = new BdCliente();
        cliente.adicionaCliente();
        JFCliente janela = new JFCliente();
        janela.setVisible(true);
        Livro livro1 = new Livro("As Crônicas de Nárnia","pong",1,2000,"s");
        BdLivro conexao = new BdLivro();
        conexao.adicionaLivro(livro1);*/
        FormCliente formCliente = new FormCliente();
        formCliente.setVisible(true);


    }
}
