package Controller;

import Model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BdCliente {
    private Connection conexao;
    public BdCliente() throws SQLException {
        this.conexao = CriarConexao.getConexao();
    }
    //Adicionar um Registro
    public void adicionaCliente() throws SQLException{
        String sql ="INSERT INTO cliente(nome, data_nasc, sexo, cpf, endereco, fone)" +
                "VALUES(?,?,?,?,?,?)";
        PreparedStatement stmt; // mesma coisa do cursor do python
        stmt = this.conexao.prepareStatement(sql);

        stmt.setString(1,"Pong");
        stmt.setString(2,"1999/05/02");
        stmt.setString(3,"M");
        stmt.setString(4,"24.235.689");
        stmt.setString(5,"Pongolandia, 69");
        stmt.setString(6,"123456");

        stmt.execute();
        stmt.close();
    }
}
